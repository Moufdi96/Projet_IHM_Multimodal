
from dollarRecognizer import*

a = ShapeReconizer()