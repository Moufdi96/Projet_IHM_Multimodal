from speecheRecognizer import*

reco = VoiceRecognizer()
reco.startVoiceReco()